<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<div id="wrapper">
<div class="wrap">
<div class="status_container">
<div class="status">

<div class="stat1">
<h3><?=$privetstvie?></h3>
<p>СТАРТ ПРОЕКТА</p>   
</div>

<div class="stat1">
<h3><?=$invcount+$user_feik?></h3>
<p>ИНВЕСТОРОВ</p>   
</div>

<div class="stat1">
<h3><?=$depmoney?> Р</h3>
<p>ИНВЕСТИРОВАНО</p>   
</div>

<div class="stat1">
<h3><?=$wthmoneyall?> Р</h3>
<p>ВЫПЛАЧЕНО</p>   
</div>

</div>
</div>
   

</div>
</div>

<div id="wrapper">    
<div class="wrap">
<div class="about_container">
<div class="about_text">
<h4>Добро пожаловать на</h4>
<h3><?=$sitename?></h3>
      
<p><?=$sitename?> - является глобальной фирмой по управлению активами, основанной в 2017 году и управляется командой опытных менеджеров, проводящих глубокие фундаментальные исследования для выявления инвестиций, торгующих на материальной дислокации от справедливой стоимости. Ключ к инвестиционному подходу <?=$sitename?> обладает экспертными знаниями в области выявления и оценки последующих изменений, поскольку они часто являются катализатором для убедительных возможностей.  <br>
<?=$sitename?> стремится обеспечить высокий годовой доход, скорректированный на риск, на протяжении всего инвестиционного цикла, захватывая большую часть на сильных рынках и сохраняя капитал на сложных рынках. <?=$sitename?> считает, что отбор акций на основе тщательного фундаментального анализа помогает генерировать положительные результаты в течение длительного времени.</p>
     
</div>
<div class="about_img"></div>
</div>
</div>
</div>
<div id="wrapper">
<div class="wrap">
<div class="plan_container">
<h3 class="fancy"><span>НАШ ТАРИФНЫЙ ПЛАН</span></h3>
<h4>МЫ ПРЕДЛАГАЕМ САМЫЙ ПЕРСПЕКТИВНЫЙ ИНВЕСТИЦИОННЫЙ ТАРИФНЫЙ ПЛАН.</h4>
<div class="plan">
<div class="ptitle">
План
<br>
</div>
<div class="min">СУММА <?=$mindep?>Р - <?=$maxdep?>Р</div>
<div class="pay"> 1<?=$deppercentage?>%<br>
<span>сроком - <?=$timeprofit?></span></div><!-- pay--> 
<div class="pay1">Тело депозита<br>ВКЛЮЧЕНО
</div> 
<div class="invest">
<span>Автовыплата</span>
</div>
</div>
</div>
</div>
</div>
<div id="wrapper">
<div class="wrap">
<div class="why_container">
<h3 class="fancy2"><span>ПОЧЕМУ ВЫБИРАЮТ НАС?</span></h3>
<p><?=$sitename?> предлагает революционные инвестиционные условия, которые подходят для самых требовательных манимейкеров!</p>
<div class="why">
<img src="pay_files/home-img.png" alt="img1">
<div class="why_txt">      
<h4>РАЗВИТИЕ</h4>
<p>Наша команда круглосуточно отслеживает все тенденции на рынке в области BTC. </p>
</div>
</div>
<div class="why">
<img src="pay_files/why-img2.png" alt="img1">
<div class="why_txt">      
<h4>ДОСТОИНСТВА</h4>
<p>Наша компания официально зарегистрирована в нескольких странах на законных правах.</p>
</div>
</div>
<div class="why">
<img src="pay_files/why-img3.png" alt="img1">
<div class="why_txt">      
<h4>МАРКЕТИНГ</h4>
<p>Мы готовы Вам предложить один из самых привлекательных тарифов на инвест рынке. </p>
</div>
</div>
<div class="why">
<img src="pay_files/why-img4.png" alt="img1">
<div class="why_txt" style="    margin-left: 14px;">      
<h4>ЭПС ПРОЕКТА</h4>
<p>Мы работаем с популярной платежной системой PAYEER. Все операции в рублях.</p>
</div>
</div>
<div class="why">
<img src="pay_files/why-img5.png" alt="img1">
<div class="why_txt">      
<h4>ВЫПЛАТЫ</h4>
<p>Все выплаты по депозитам полностью автоматические и срабатывают от 1 рубля.</p>
</div>
</div>
<div class="why">
<img src="pay_files/why-img6.png" alt="img1">
<div class="why_txt">      
<h4>24/7 ПОДДЕРЖКА</h4>
<p>Наша служба поддержки готова Вам помочь в любое время. Мы готовы Вам помочь.</p>
</div>
</div>
</div>
</div> 
</div>
<div id="wrapper">
<div class="wrap">
<div class="affliate_container">
<div class="affliate_rbg">  
<div class="affliate_r">  
<div class="affliate_txt">      
<h3>Партнерская</h3>
<h4 style="">Программа</h4>
<p style="    float: right;    width: 23%;    margin-top: 11px">Партнерская комиссия</p>
<h4 style="color:#f50073; font-size:47px;      font-weight: bold; float:right;"> <?=$refpercent?>%</h4>
</div>
<div class="ref_btn">
<a href="#">1 уровень</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="wrapper">
<div class="wrap">
<div class="payment_container">
<div class="payment_in">
<div class="payment">
<h3>Платежная система</h3>
<img src="pay_files/payeer-img.png">
</div>
<div class="security">
<h3>Система безопасности</h3>
<img src="pay_files/comodo-img.png">
<img src="pay_files/ddos-img.png">   
</div>
</div>
</div>
</div>
</div>
<div class="clear"></div>

<?/*-------------------*//*
Web-site: php-scripts.ru
*//*-------------------*/?>