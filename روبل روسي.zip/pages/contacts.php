<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<div style="width: 1200px;margin: 0 auto;min-height: 410px;">
<p align="left" style="padding-left:10px; text-align:center"><strong>Связь с администрацией</strong></p><br>
<p align="left" style="width:1000px;padding-left:20px;padding-right: 20px;text-align: center;margin: 0 auto;background: #fff;border-radius: 8px; color:#30125a;">
Старайтесь как можно подробнее опись Ваш вопрос.<br>Регламент обработки всех обращений 24 часа с момента обращения.<br><br>
Перед обращением укажите в письме свой логин (payeer кошелек) <br><strong><span><?=$adminmail?></span></strong><br>

</p>
</div>
<?/*-------------------*//*
Web-site: php-scripts.ru
*//*-------------------*/?>