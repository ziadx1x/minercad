<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<div style="
    width: 868px;
    margin: 0 auto;
    text-align: center;
">
                    <b>ТАКОЙ СТРАНИЦЫ НЕ СУЩЕСТВУЕТ!</b>
</div>			  
<?/*-------------------*//*
Web-site: php-scripts.ru
*//*-------------------*/?>