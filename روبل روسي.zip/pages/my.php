<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<p align="left" style="padding-left:10px; text-align:center">СПИСОК ВАШИХ ДЕПОЗИТОВ<br>ВСЕ ВЫПЛАТЫ ОБРАБАТЫВАЮТСЯ В ПОРЯДКЕ ОЧЕРЕДИ</p>
<div style="width: 1200px;margin: 0 auto;min-height: 410px;">
<table width="1200px" cellpadding="5" cellspacing="5" id="tables"  class="animated zoomIn" style="border-radius:8px;">
<tbody>
  <tr style="text-transform: uppercase;">
    <td align="center" width="150px"><b>Дата вклада</b></td>
	<td align="center" width="100px"><b>Кошелек</b></td>
	<td align="center" width="100px"><b>Сумма</b></td>
	<td align="center" width="100px"><b>Осталось</b></td>
	<td align="center" width="100px"><b>Доход</b></td>
  </tr>  
  
 

<? 

$checkdeps=$db->getOne("SELECT id FROM `deposits` WHERE userid=?i AND curatorid!=?i LIMIT 1",$id,0);
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `deposits` WHERE userid=?i AND curatorid!=?i ORDER BY id DESC LIMIT 20",$id,0);
  
while($deposits=$db->fetch($depositsrow)){?>  
	<tr align="center" height="25">
	<td align="center"><?=date('d.m.Y H:i',$deposits['unixtime'])?></td>
	
<?
$wallet=substr($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']), 0); 
?>	
	
	
	<td align="center"><?=$wallet?></td>
    <td align="center"><?=$deposits['summa']?> <i class="fa fa-rub" aria-hidden="true"></i></td>
	
<?/*
$seconds = time()-(60*($depperiod-24))-$deposits['unixtime'];

if($seconds>(3600*$depperiod)){
	$deptime="Выплачено";
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=24-($hours+1);
if($h<10){$h='0'.$h;}
$m=60-($minutes+1);
if($m<10){$m='0'.$m;}
$s=60-($seconds+1);
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}*/
$seconds = time()-$deposits['unixtime']; //Секунд прошло с момента депа

$seconds=(60*($depperiod))-$seconds; //Длительность депа, минус прошло = осталось
//echo "<br>".date('H:i:s',time());
//echo "<br>".date('H:i:s',$deposits['unixtime'])."<br>".$seconds;
if($seconds<1){
    if($deposits['status']==1){
	$deptime="Выплачено";}else{
	$deptime="Выплачивается";
	}
}else{
	
$hours = floor($seconds/3600);
$seconds = $seconds-($hours*3600);
$minutes = floor($seconds/60);
$seconds = $seconds-($minutes*60);
$seconds = floor($seconds);



$h=$hours;
if($h<10){$h='0'.$h;}
$m=$minutes;
if($m<10){$m='0'.$m;}
$s=$seconds;
if($s<10){$s='0'.$s;}
	$deptime=$h.":".$m.":".$s;
}
?>	
	
	<td class="countdown" align="center"><?=$deptime?></td>
	
<?$psumma=$deposits['summa']+($deposits['summa']*($deppercentage/100));?>	
	
	<td align="center"><?=$psumma?> <i class="fa fa-rub" aria-hidden="true"></i></td>
  	</tr>
<?}}else{?> 
<center>У вас нет открытых вкладов</center>
<?}?>

  </tbody>
 </table>
 </div>
<br>

<?/*-------------------*//*
Web-site: php-scripts.ru
*//*-------------------*/?>