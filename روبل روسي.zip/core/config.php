<?php

/*
ВАЖНО!
Админ должен быть с ID=1 (Зарегистрирован на проекте первым)
*/

if(!defined('SCRIPT_BY_SIRGOFFAN')){

echo ('Выявлена попытка взлома!');
exit();
}

$bd_host = "localhost";
$bd_user = "root"; // юзер
$bd_password = "";  // пасс
$bd_base = "haip"; // БД

$db = new SafeMySQL(array('user' => $bd_user, 'pass' => $bd_password, 'db' => $bd_base, 'charset' => 'utf8'));

//НАСТРОЙКА ПРОЕКТА
$ssl_connect="https";//Ваше соединение http или https (Для реф ссылок и баннера)
$itworks=1; //Режим работы сайта. 1 - сайт работает, 0 - регистрация закрыта
$sitename="BIT CASH"; //Название проекта
$adminmail="admin@com"; //Почта администрации
$vkgrup="https://vk.com/"; //Вк группа
$telega="https://t.me"; //Телеграм
$twitter="#"; //Twitter
$facebook="#"; //Facebook
$str_otziv="#"; //Ссылка на страницу с отзывами
$privetstvie='18-04-2019'; //Дата старта
$timeprofit="24 часа"; //Время вклада в часах для шапки и faq
$banner="/468x60.png"; //Ссылка на баннер проекта
$koshelek_admina=''; //Кошелек админа

//ПРИЕМ СРЕДСТВ (мерчант):
$m_shop = ''; //ID магазина в системе Payeer
$m_desc = 'Открытие вклада '.$sitename; //Текст комментария к платежу
$m_key = ''; //Ключ от магазина

//ВЫПЛАТА (api):
$accountNumber = '';  //Счет, с которого будут происходить выплаты
$apiId = ''; //ID API
$apiKey = ''; //Секретный ключ API
$m_curr='RUB'; //Валюта проекта

//МАРКЕТИНГ ПРОЕКТА
$mindep=50; //Минимальный размер депозита
$maxdep=5000; //Максимальный размер депозита
$refpercent=7; //Реф. процент
$admpercent=10; //Админский процент
$depperiod=500000; //Время вклада (В минутах)
$deppercentage=15; //Процентаж (+ сколько к сумме депа)
$refrezhim=1; //Режим выплаты реферальных: 1 - в момент депа рефералом, 2 - в момент окончания срока депа реферала

//НАКРУТКА СТАТИСТИКИ
$user_feik=0; //Фейковых юзеров
$depmoney_feik=0; //Сумма ко вкладам
$wthmoneyall_feik=0; //Сумма выплат

//ВОЗВРАТ ПО АКЦИИ
$bonus_act = 0; //Режим акции. 1 - акция активна, 0 - отключена
$bonus_minsum=10; //Минимальный вклад, при котором активируется возврат по акции
$bonus_percent=20; //Процентаж, сколько процентов ворачивается
/*Как работает акция.*/
//Допустим, $bonus_minsum=1000, а $bonus_percent=10. Это значит, что при вкладе пользователем на сумму превышающую 1000 рублей, ему незамедлительно ворачивается 10%

//НАСТРОЙКИ НЕ МЕНЯТЬ
$adminsecretcode='kNbHh3HCPd';
$adminadress="admin";
$admintoken="wgwgwsbvgsd7weshvf7sevgfs";
$admintoken=md5($admintoken.date("d.m.Y"));
$use_kapcha=0;
$http_s="http";
$nocron=0;

/**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**//**/

//Script by php-scripts.ru
?>