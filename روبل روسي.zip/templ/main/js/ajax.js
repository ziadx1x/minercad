   function vklad() {
	   var phone = $('#phone').val();
	   if(phone != ""){
        document.getElementById('vkladi').disabled = true;

                $.ajax({
                    url: "/deposit.php", //Адрес подгружаемой страницы
                    type:     "POST", //Тип запроса
                    data:"phone="+phone, 
                    success: function(response) { //Если все нормально
                document.getElementById('pay_message').innerHTML = response;
        document.getElementById('vkladi').disabled = false;

$('#pay_message').css({'display':'block'});
$('#pay_block').css({'display':'none'});
$('#alert').html(""+phone+" добавлен в базу");
$('#alert').delay(3000).fadeIn(1000);

outalert();
                },
                error: function(response) { //Если ошибка
                document.getElementById(result_id).innerHTML = "Ошибка при отправке формы";
                }
             });
	   }
        }

function outalert(){
$("#alert").delay(5000).fadeOut(2000);
}

function new_pay(){
$('#pay_message').css({'display':'none'});
$('#pay_block').css({'display':'block'});
}