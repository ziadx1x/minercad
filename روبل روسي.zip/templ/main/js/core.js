function play_sound(){val='/themes/sound/alert';if($('#sound').length){}else{sound_init('#sound',val);}}
function sound_init(id,sound){setTimeout(function(){clear_sound(id)},3000)
return $("<embed id="+id+" src='"+val+".mp3' hidden='true' autostart='true' loop='false' class='playSound'>"+"<audio autoplay='autoplay' style='display:none;' controls='controls'><source src='"+val+".mp3' /><source src='"+val+".ogg' /></audio>").appendTo('body');}
function clear_sound(id){$(id).remove();}
var clipboard=new Clipboard('.clipboard');clipboard.on('success',function(e){console.log(e);});clipboard.on('error',function(e){console.log(e);});function isTouchDevice(){return'ontouchstart'in document.documentElement;}