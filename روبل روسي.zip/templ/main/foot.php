<div id="wrapper">  
<div class="footer_bg">
<div class="wrap">
<div class="footer_container">
<div class="foot1">
<h3>Навигация</h3>
<div class="fmenu">
<ul>
<li> <a href="/">Главная</a> </li>
<li> <a href="/?page=about">О проекте</a> </li>
</ul>
</div> 
<div class="fmenu">
<ul>
<li> 
<a href="/?page=rules">Правила</a>
</li>
</ul>
</div> 

<div class="fmenu">
<ul>
<li> <a href="/?page=faq">FAQ</a> </li>
<li> <a href="/?page=contacts">Поддержка</a> </li>
</ul>
</div>   

<div class="copy">
<p><a href="#">E&D © 2018 <?=$sitename?></a></p>
</div>
</div>
<div class="foot3">
<div class="fsocial">
<a href="<?=$vkgrup?>" target="_blank"><img src="pay_files/vkontakte.png"></a>
<a href="<?=$telega?>" target="_blank"><img src="pay_files/Telegram.png"></a>
</div>
</div>
<div class="foot2">
<h3>Сертификат компании</h3>
<img src="pay_files/certificate.png" alt="img2">
<div class="foot2_text">
<p>#10372977</p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="clear"></div>
<style type="text/css">#hellopreloader>p{display:none;}#hellopreloader_preload{display: block;position: fixed;z-index: 99999;top: 0;left: 0;width: 100%;height: 100%;min-width: 1000px;background: #663399 url(/img/ball-triangle.svg) center center no-repeat;background-size:141px;}</style>
<div id="hellopreloader"><div id="hellopreloader_preload"></div></div>
<script type="text/javascript">var hellopreloader = document.getElementById("hellopreloader_preload");function fadeOutnojquery(el){el.style.opacity = 1;var interhellopreloader = setInterval(function(){el.style.opacity = el.style.opacity - 0.05;if (el.style.opacity <=0.05){ clearInterval(interhellopreloader);hellopreloader.style.display = "none";}},16);}window.onload = function(){setTimeout(function(){fadeOutnojquery(hellopreloader);},1000);};</script>
<!-- HelloPreload -->
</body></html>